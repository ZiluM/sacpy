import sacpy as scp
import xarray as xr
import matplotlib.pyplot as plt
import sacpy.Map
import copy

sst = scp.load_sst()['sst']

coords = sst.coords
dim = sst.dims


coords1 = copy.deepcopy(coords)

del(coords1[dim[0]])

# print(coords.pop("time"))
print(coords1)

# newcoords = {dim[i]:coords[dim[i]] for i in range(len(dim))}
# newcoords.keys[0] = "time1"

# print(newcoords)
# print(dim)
# newc = coords

# print(type(coords))