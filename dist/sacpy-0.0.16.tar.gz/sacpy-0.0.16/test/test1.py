import numpy as np

print(f"{np.ndarray}")